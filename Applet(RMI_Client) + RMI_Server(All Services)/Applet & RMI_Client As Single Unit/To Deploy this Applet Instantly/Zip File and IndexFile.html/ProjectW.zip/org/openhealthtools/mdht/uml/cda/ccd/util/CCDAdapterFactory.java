/*******************************************************************************
 * Copyright (c) 2009, 2012 IBM Corporation and others.
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 *
 * Contributors:
 *     IBM Corporation - initial API and implementation
 *******************************************************************************/
package org.openhealthtools.mdht.uml.cda.ccd.util;

import org.eclipse.emf.common.notify.Adapter;
import org.eclipse.emf.common.notify.Notifier;
import org.eclipse.emf.common.notify.impl.AdapterFactoryImpl;
import org.eclipse.emf.ecore.EObject;
import org.openhealthtools.mdht.uml.cda.AssignedEntity;
import org.openhealthtools.mdht.uml.cda.ClinicalDocument;
import org.openhealthtools.mdht.uml.cda.ClinicalStatement;
import org.openhealthtools.mdht.uml.cda.Encounter;
import org.openhealthtools.mdht.uml.cda.Guardian;
import org.openhealthtools.mdht.uml.cda.ManufacturedProduct;
import org.openhealthtools.mdht.uml.cda.Observation;
import org.openhealthtools.mdht.uml.cda.Organizer;
import org.openhealthtools.mdht.uml.cda.Participant1;
import org.openhealthtools.mdht.uml.cda.Participant2;
import org.openhealthtools.mdht.uml.cda.ParticipantRole;
import org.openhealthtools.mdht.uml.cda.Procedure;
import org.openhealthtools.mdht.uml.cda.Reference;
import org.openhealthtools.mdht.uml.cda.RegistryDelegate;
import org.openhealthtools.mdht.uml.cda.Section;
import org.openhealthtools.mdht.uml.cda.SubstanceAdministration;
import org.openhealthtools.mdht.uml.cda.Supply;
import org.openhealthtools.mdht.uml.cda.ccd.AdvanceDirectiveObservation;
import org.openhealthtools.mdht.uml.cda.ccd.AdvanceDirectiveReference;
import org.openhealthtools.mdht.uml.cda.ccd.AdvanceDirectiveStatusObservation;
import org.openhealthtools.mdht.uml.cda.ccd.AdvanceDirectiveVerification;
import org.openhealthtools.mdht.uml.cda.ccd.AdvanceDirectivesSection;
import org.openhealthtools.mdht.uml.cda.ccd.AgeObservation;
import org.openhealthtools.mdht.uml.cda.ccd.AlertObservation;
import org.openhealthtools.mdht.uml.cda.ccd.AlertStatusObservation;
import org.openhealthtools.mdht.uml.cda.ccd.AlertsSection;
import org.openhealthtools.mdht.uml.cda.ccd.AuthorizationActivity;
import org.openhealthtools.mdht.uml.cda.ccd.CCDPackage;
import org.openhealthtools.mdht.uml.cda.ccd.CCDRegistryDelegate;
import org.openhealthtools.mdht.uml.cda.ccd.CauseOfDeathObservation;
import org.openhealthtools.mdht.uml.cda.ccd.Comment;
import org.openhealthtools.mdht.uml.cda.ccd.ContinuityOfCareDocument;
import org.openhealthtools.mdht.uml.cda.ccd.CoverageActivity;
import org.openhealthtools.mdht.uml.cda.ccd.CoveragePlanDescription;
import org.openhealthtools.mdht.uml.cda.ccd.CoveredParty;
import org.openhealthtools.mdht.uml.cda.ccd.EncounterLocation;
import org.openhealthtools.mdht.uml.cda.ccd.EncountersActivity;
import org.openhealthtools.mdht.uml.cda.ccd.EncountersSection;
import org.openhealthtools.mdht.uml.cda.ccd.EpisodeObservation;
import org.openhealthtools.mdht.uml.cda.ccd.FamilyHistoryCauseOfDeathObservation;
import org.openhealthtools.mdht.uml.cda.ccd.FamilyHistoryObservation;
import org.openhealthtools.mdht.uml.cda.ccd.FamilyHistoryOrganizer;
import org.openhealthtools.mdht.uml.cda.ccd.FamilyHistorySection;
import org.openhealthtools.mdht.uml.cda.ccd.FulfillmentInstruction;
import org.openhealthtools.mdht.uml.cda.ccd.FunctionalStatusObservation;
import org.openhealthtools.mdht.uml.cda.ccd.FunctionalStatusSection;
import org.openhealthtools.mdht.uml.cda.ccd.ImmunizationsSection;
import org.openhealthtools.mdht.uml.cda.ccd.MedicalEquipmentSection;
import org.openhealthtools.mdht.uml.cda.ccd.MedicationActivity;
import org.openhealthtools.mdht.uml.cda.ccd.MedicationSeriesNumberObservation;
import org.openhealthtools.mdht.uml.cda.ccd.MedicationStatusObservation;
import org.openhealthtools.mdht.uml.cda.ccd.MedicationsSection;
import org.openhealthtools.mdht.uml.cda.ccd.PatientAwareness;
import org.openhealthtools.mdht.uml.cda.ccd.PatientInstruction;
import org.openhealthtools.mdht.uml.cda.ccd.PayerEntity;
import org.openhealthtools.mdht.uml.cda.ccd.PayersSection;
import org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivity;
import org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivityAct;
import org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivityEncounter;
import org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivityObservation;
import org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivityProcedure;
import org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivitySubstanceAdministration;
import org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivitySupply;
import org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareSection;
import org.openhealthtools.mdht.uml.cda.ccd.PolicyActivity;
import org.openhealthtools.mdht.uml.cda.ccd.PolicySubscriber;
import org.openhealthtools.mdht.uml.cda.ccd.ProblemAct;
import org.openhealthtools.mdht.uml.cda.ccd.ProblemHealthStatusObservation;
import org.openhealthtools.mdht.uml.cda.ccd.ProblemObservation;
import org.openhealthtools.mdht.uml.cda.ccd.ProblemSection;
import org.openhealthtools.mdht.uml.cda.ccd.ProblemStatusObservation;
import org.openhealthtools.mdht.uml.cda.ccd.ProcedureActivity;
import org.openhealthtools.mdht.uml.cda.ccd.ProcedureActivityAct;
import org.openhealthtools.mdht.uml.cda.ccd.ProcedureActivityObservation;
import org.openhealthtools.mdht.uml.cda.ccd.ProcedureActivityProcedure;
import org.openhealthtools.mdht.uml.cda.ccd.ProceduresSection;
import org.openhealthtools.mdht.uml.cda.ccd.Product;
import org.openhealthtools.mdht.uml.cda.ccd.ProductInstance;
import org.openhealthtools.mdht.uml.cda.ccd.PurposeActivity;
import org.openhealthtools.mdht.uml.cda.ccd.PurposeSection;
import org.openhealthtools.mdht.uml.cda.ccd.ReactionObservation;
import org.openhealthtools.mdht.uml.cda.ccd.ResultObservation;
import org.openhealthtools.mdht.uml.cda.ccd.ResultOrganizer;
import org.openhealthtools.mdht.uml.cda.ccd.ResultsSection;
import org.openhealthtools.mdht.uml.cda.ccd.SeverityObservation;
import org.openhealthtools.mdht.uml.cda.ccd.SocialHistoryObservation;
import org.openhealthtools.mdht.uml.cda.ccd.SocialHistorySection;
import org.openhealthtools.mdht.uml.cda.ccd.SocialHistoryStatusObservation;
import org.openhealthtools.mdht.uml.cda.ccd.StatusObservation;
import org.openhealthtools.mdht.uml.cda.ccd.SupplyActivity;
import org.openhealthtools.mdht.uml.cda.ccd.Support;
import org.openhealthtools.mdht.uml.cda.ccd.SupportGuardian;
import org.openhealthtools.mdht.uml.cda.ccd.SupportParticipant;
import org.openhealthtools.mdht.uml.cda.ccd.VitalSignsOrganizer;
import org.openhealthtools.mdht.uml.cda.ccd.VitalSignsSection;
import org.openhealthtools.mdht.uml.hl7.rim.Act;
import org.openhealthtools.mdht.uml.hl7.rim.ActRelationship;
import org.openhealthtools.mdht.uml.hl7.rim.InfrastructureRoot;
import org.openhealthtools.mdht.uml.hl7.rim.Participation;
import org.openhealthtools.mdht.uml.hl7.rim.Role;

/**
 * <!-- begin-user-doc -->
 * The <b>Adapter Factory</b> for the model.
 * It provides an adapter <code>createXXX</code> method for each class of the model.
 * <!-- end-user-doc -->
 * @see org.openhealthtools.mdht.uml.cda.ccd.CCDPackage
 * @generated
 */
public class CCDAdapterFactory extends AdapterFactoryImpl {
	/**
	* The cached model package.
	* <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	* @generated
	*/
	protected static CCDPackage modelPackage;

	/**
	* Creates an instance of the adapter factory.
	* <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	* @generated
	*/
	public CCDAdapterFactory() {
		if (modelPackage == null) {
			modelPackage = CCDPackage.eINSTANCE;
		}
	}

	/**
	* Returns whether this factory is applicable for the type of the object.
	* <!-- begin-user-doc -->
	 * This implementation returns <code>true</code> if the object is either the model's package or is an instance object of the model.
	 * <!-- end-user-doc -->
	* @return whether this factory is applicable for the type of the object.
	* @generated
	*/
	@Override
	public boolean isFactoryForType(Object object) {
		if (object == modelPackage) {
			return true;
		}
		if (object instanceof EObject) {
			return ((EObject) object).eClass().getEPackage() == modelPackage;
		}
		return false;
	}

	/**
	* The switch that delegates to the <code>createXXX</code> methods.
	* <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	* @generated
	*/
	protected CCDSwitch<Adapter> modelSwitch = new CCDSwitch<Adapter>() {
		@Override
		public Adapter caseMedicationsSection(MedicationsSection object) {
			return createMedicationsSectionAdapter();
		}

		@Override
		public Adapter caseMedicationActivity(MedicationActivity object) {
			return createMedicationActivityAdapter();
		}

		@Override
		public Adapter caseMedicationSeriesNumberObservation(MedicationSeriesNumberObservation object) {
			return createMedicationSeriesNumberObservationAdapter();
		}

		@Override
		public Adapter caseMedicationStatusObservation(MedicationStatusObservation object) {
			return createMedicationStatusObservationAdapter();
		}

		@Override
		public Adapter caseStatusObservation(StatusObservation object) {
			return createStatusObservationAdapter();
		}

		@Override
		public Adapter casePatientInstruction(PatientInstruction object) {
			return createPatientInstructionAdapter();
		}

		@Override
		public Adapter caseReactionObservation(ReactionObservation object) {
			return createReactionObservationAdapter();
		}

		@Override
		public Adapter caseSeverityObservation(SeverityObservation object) {
			return createSeverityObservationAdapter();
		}

		@Override
		public Adapter caseProductInstance(ProductInstance object) {
			return createProductInstanceAdapter();
		}

		@Override
		public Adapter caseSupplyActivity(SupplyActivity object) {
			return createSupplyActivityAdapter();
		}

		@Override
		public Adapter caseFulfillmentInstruction(FulfillmentInstruction object) {
			return createFulfillmentInstructionAdapter();
		}

		@Override
		public Adapter caseContinuityOfCareDocument(ContinuityOfCareDocument object) {
			return createContinuityOfCareDocumentAdapter();
		}

		@Override
		public Adapter caseProblemSection(ProblemSection object) {
			return createProblemSectionAdapter();
		}

		@Override
		public Adapter caseProblemAct(ProblemAct object) {
			return createProblemActAdapter();
		}

		@Override
		public Adapter caseEpisodeObservation(EpisodeObservation object) {
			return createEpisodeObservationAdapter();
		}

		@Override
		public Adapter caseFamilyHistorySection(FamilyHistorySection object) {
			return createFamilyHistorySectionAdapter();
		}

		@Override
		public Adapter caseFamilyHistoryOrganizer(FamilyHistoryOrganizer object) {
			return createFamilyHistoryOrganizerAdapter();
		}

		@Override
		public Adapter caseFamilyHistoryObservation(FamilyHistoryObservation object) {
			return createFamilyHistoryObservationAdapter();
		}

		@Override
		public Adapter caseAgeObservation(AgeObservation object) {
			return createAgeObservationAdapter();
		}

		@Override
		public Adapter caseProblemStatusObservation(ProblemStatusObservation object) {
			return createProblemStatusObservationAdapter();
		}

		@Override
		public Adapter caseSocialHistorySection(SocialHistorySection object) {
			return createSocialHistorySectionAdapter();
		}

		@Override
		public Adapter caseSocialHistoryObservation(SocialHistoryObservation object) {
			return createSocialHistoryObservationAdapter();
		}

		@Override
		public Adapter caseSocialHistoryStatusObservation(SocialHistoryStatusObservation object) {
			return createSocialHistoryStatusObservationAdapter();
		}

		@Override
		public Adapter caseAlertsSection(AlertsSection object) {
			return createAlertsSectionAdapter();
		}

		@Override
		public Adapter caseResultsSection(ResultsSection object) {
			return createResultsSectionAdapter();
		}

		@Override
		public Adapter caseResultOrganizer(ResultOrganizer object) {
			return createResultOrganizerAdapter();
		}

		@Override
		public Adapter caseResultObservation(ResultObservation object) {
			return createResultObservationAdapter();
		}

		@Override
		public Adapter caseProceduresSection(ProceduresSection object) {
			return createProceduresSectionAdapter();
		}

		@Override
		public Adapter caseEncountersSection(EncountersSection object) {
			return createEncountersSectionAdapter();
		}

		@Override
		public Adapter caseEncountersActivity(EncountersActivity object) {
			return createEncountersActivityAdapter();
		}

		@Override
		public Adapter casePlanOfCareSection(PlanOfCareSection object) {
			return createPlanOfCareSectionAdapter();
		}

		@Override
		public Adapter casePlanOfCareActivity(PlanOfCareActivity object) {
			return createPlanOfCareActivityAdapter();
		}

		@Override
		public Adapter casePlanOfCareActivityAct(PlanOfCareActivityAct object) {
			return createPlanOfCareActivityActAdapter();
		}

		@Override
		public Adapter casePlanOfCareActivityEncounter(PlanOfCareActivityEncounter object) {
			return createPlanOfCareActivityEncounterAdapter();
		}

		@Override
		public Adapter casePlanOfCareActivityObservation(PlanOfCareActivityObservation object) {
			return createPlanOfCareActivityObservationAdapter();
		}

		@Override
		public Adapter casePlanOfCareActivityProcedure(PlanOfCareActivityProcedure object) {
			return createPlanOfCareActivityProcedureAdapter();
		}

		@Override
		public Adapter casePlanOfCareActivitySubstanceAdministration(PlanOfCareActivitySubstanceAdministration object) {
			return createPlanOfCareActivitySubstanceAdministrationAdapter();
		}

		@Override
		public Adapter casePlanOfCareActivitySupply(PlanOfCareActivitySupply object) {
			return createPlanOfCareActivitySupplyAdapter();
		}

		@Override
		public Adapter caseImmunizationsSection(ImmunizationsSection object) {
			return createImmunizationsSectionAdapter();
		}

		@Override
		public Adapter caseVitalSignsSection(VitalSignsSection object) {
			return createVitalSignsSectionAdapter();
		}

		@Override
		public Adapter caseVitalSignsOrganizer(VitalSignsOrganizer object) {
			return createVitalSignsOrganizerAdapter();
		}

		@Override
		public Adapter caseMedicalEquipmentSection(MedicalEquipmentSection object) {
			return createMedicalEquipmentSectionAdapter();
		}

		@Override
		public Adapter caseFunctionalStatusSection(FunctionalStatusSection object) {
			return createFunctionalStatusSectionAdapter();
		}

		@Override
		public Adapter caseAdvanceDirectivesSection(AdvanceDirectivesSection object) {
			return createAdvanceDirectivesSectionAdapter();
		}

		@Override
		public Adapter caseAdvanceDirectiveObservation(AdvanceDirectiveObservation object) {
			return createAdvanceDirectiveObservationAdapter();
		}

		@Override
		public Adapter caseAdvanceDirectiveStatusObservation(AdvanceDirectiveStatusObservation object) {
			return createAdvanceDirectiveStatusObservationAdapter();
		}

		@Override
		public Adapter casePayersSection(PayersSection object) {
			return createPayersSectionAdapter();
		}

		@Override
		public Adapter caseCoverageActivity(CoverageActivity object) {
			return createCoverageActivityAdapter();
		}

		@Override
		public Adapter casePolicyActivity(PolicyActivity object) {
			return createPolicyActivityAdapter();
		}

		@Override
		public Adapter casePurposeSection(PurposeSection object) {
			return createPurposeSectionAdapter();
		}

		@Override
		public Adapter casePurposeActivity(PurposeActivity object) {
			return createPurposeActivityAdapter();
		}

		@Override
		public Adapter caseProblemObservation(ProblemObservation object) {
			return createProblemObservationAdapter();
		}

		@Override
		public Adapter caseProblemHealthStatusObservation(ProblemHealthStatusObservation object) {
			return createProblemHealthStatusObservationAdapter();
		}

		@Override
		public Adapter casePatientAwareness(PatientAwareness object) {
			return createPatientAwarenessAdapter();
		}

		@Override
		public Adapter caseAlertObservation(AlertObservation object) {
			return createAlertObservationAdapter();
		}

		@Override
		public Adapter caseAlertStatusObservation(AlertStatusObservation object) {
			return createAlertStatusObservationAdapter();
		}

		@Override
		public Adapter caseCauseOfDeathObservation(CauseOfDeathObservation object) {
			return createCauseOfDeathObservationAdapter();
		}

		@Override
		public Adapter caseEncounterLocation(EncounterLocation object) {
			return createEncounterLocationAdapter();
		}

		@Override
		public Adapter caseProduct(Product object) {
			return createProductAdapter();
		}

		@Override
		public Adapter caseAdvanceDirectiveVerification(AdvanceDirectiveVerification object) {
			return createAdvanceDirectiveVerificationAdapter();
		}

		@Override
		public Adapter caseAuthorizationActivity(AuthorizationActivity object) {
			return createAuthorizationActivityAdapter();
		}

		@Override
		public Adapter caseProcedureActivity(ProcedureActivity object) {
			return createProcedureActivityAdapter();
		}

		@Override
		public Adapter caseFunctionalStatusObservation(FunctionalStatusObservation object) {
			return createFunctionalStatusObservationAdapter();
		}

		@Override
		public Adapter caseProcedureActivityAct(ProcedureActivityAct object) {
			return createProcedureActivityActAdapter();
		}

		@Override
		public Adapter caseProcedureActivityObservation(ProcedureActivityObservation object) {
			return createProcedureActivityObservationAdapter();
		}

		@Override
		public Adapter caseProcedureActivityProcedure(ProcedureActivityProcedure object) {
			return createProcedureActivityProcedureAdapter();
		}

		@Override
		public Adapter casePayerEntity(PayerEntity object) {
			return createPayerEntityAdapter();
		}

		@Override
		public Adapter caseCoveredParty(CoveredParty object) {
			return createCoveredPartyAdapter();
		}

		@Override
		public Adapter casePolicySubscriber(PolicySubscriber object) {
			return createPolicySubscriberAdapter();
		}

		@Override
		public Adapter caseCoveragePlanDescription(CoveragePlanDescription object) {
			return createCoveragePlanDescriptionAdapter();
		}

		@Override
		public Adapter caseSupportParticipant(SupportParticipant object) {
			return createSupportParticipantAdapter();
		}

		@Override
		public Adapter caseSupport(Support object) {
			return createSupportAdapter();
		}

		@Override
		public Adapter caseSupportGuardian(SupportGuardian object) {
			return createSupportGuardianAdapter();
		}

		@Override
		public Adapter caseComment(Comment object) {
			return createCommentAdapter();
		}

		@Override
		public Adapter caseAdvanceDirectiveReference(AdvanceDirectiveReference object) {
			return createAdvanceDirectiveReferenceAdapter();
		}

		@Override
		public Adapter caseFamilyHistoryCauseOfDeathObservation(FamilyHistoryCauseOfDeathObservation object) {
			return createFamilyHistoryCauseOfDeathObservationAdapter();
		}

		@Override
		public Adapter caseCCDRegistryDelegate(CCDRegistryDelegate object) {
			return createCCDRegistryDelegateAdapter();
		}

		@Override
		public Adapter caseInfrastructureRoot(InfrastructureRoot object) {
			return createInfrastructureRootAdapter();
		}

		@Override
		public Adapter caseAct(Act object) {
			return createActAdapter();
		}

		@Override
		public Adapter caseSection(Section object) {
			return createSectionAdapter();
		}

		@Override
		public Adapter caseClinicalStatement(ClinicalStatement object) {
			return createClinicalStatementAdapter();
		}

		@Override
		public Adapter caseSubstanceAdministration(SubstanceAdministration object) {
			return createSubstanceAdministrationAdapter();
		}

		@Override
		public Adapter caseObservation(Observation object) {
			return createObservationAdapter();
		}

		@Override
		public Adapter caseCDA_Act(org.openhealthtools.mdht.uml.cda.Act object) {
			return createCDA_ActAdapter();
		}

		@Override
		public Adapter caseRole(Role object) {
			return createRoleAdapter();
		}

		@Override
		public Adapter caseParticipantRole(ParticipantRole object) {
			return createParticipantRoleAdapter();
		}

		@Override
		public Adapter caseSupply(Supply object) {
			return createSupplyAdapter();
		}

		@Override
		public Adapter caseClinicalDocument(ClinicalDocument object) {
			return createClinicalDocumentAdapter();
		}

		@Override
		public Adapter caseOrganizer(Organizer object) {
			return createOrganizerAdapter();
		}

		@Override
		public Adapter caseEncounter(Encounter object) {
			return createEncounterAdapter();
		}

		@Override
		public Adapter caseProcedure(Procedure object) {
			return createProcedureAdapter();
		}

		@Override
		public Adapter caseParticipation(Participation object) {
			return createParticipationAdapter();
		}

		@Override
		public Adapter caseParticipant2(Participant2 object) {
			return createParticipant2Adapter();
		}

		@Override
		public Adapter caseManufacturedProduct(ManufacturedProduct object) {
			return createManufacturedProductAdapter();
		}

		@Override
		public Adapter caseAssignedEntity(AssignedEntity object) {
			return createAssignedEntityAdapter();
		}

		@Override
		public Adapter caseParticipant1(Participant1 object) {
			return createParticipant1Adapter();
		}

		@Override
		public Adapter caseGuardian(Guardian object) {
			return createGuardianAdapter();
		}

		@Override
		public Adapter caseActRelationship(ActRelationship object) {
			return createActRelationshipAdapter();
		}

		@Override
		public Adapter caseReference(Reference object) {
			return createReferenceAdapter();
		}

		@Override
		public Adapter caseRegistryDelegate(RegistryDelegate object) {
			return createRegistryDelegateAdapter();
		}

		@Override
		public Adapter defaultCase(EObject object) {
			return createEObjectAdapter();
		}
	};

	/**
	* Creates an adapter for the <code>target</code>.
	* <!-- begin-user-doc -->
	 * <!-- end-user-doc -->
	* @param target the object to adapt.
	* @return the adapter for the <code>target</code>.
	* @generated
	*/
	@Override
	public Adapter createAdapter(Notifier target) {
		return modelSwitch.doSwitch((EObject) target);
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.MedicationsSection <em>Medications Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.MedicationsSection
	* @generated
	*/
	public Adapter createMedicationsSectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ContinuityOfCareDocument <em>Continuity Of Care Document</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ContinuityOfCareDocument
	* @generated
	*/
	public Adapter createContinuityOfCareDocumentAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ProblemSection <em>Problem Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ProblemSection
	* @generated
	*/
	public Adapter createProblemSectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ProblemAct <em>Problem Act</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ProblemAct
	* @generated
	*/
	public Adapter createProblemActAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.EpisodeObservation <em>Episode Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.EpisodeObservation
	* @generated
	*/
	public Adapter createEpisodeObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.FamilyHistorySection <em>Family History Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.FamilyHistorySection
	* @generated
	*/
	public Adapter createFamilyHistorySectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.SocialHistorySection <em>Social History Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.SocialHistorySection
	* @generated
	*/
	public Adapter createSocialHistorySectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.AlertsSection <em>Alerts Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.AlertsSection
	* @generated
	*/
	public Adapter createAlertsSectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ResultsSection <em>Results Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ResultsSection
	* @generated
	*/
	public Adapter createResultsSectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ResultOrganizer <em>Result Organizer</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ResultOrganizer
	* @generated
	*/
	public Adapter createResultOrganizerAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ResultObservation <em>Result Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ResultObservation
	* @generated
	*/
	public Adapter createResultObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ProceduresSection <em>Procedures Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ProceduresSection
	* @generated
	*/
	public Adapter createProceduresSectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.EncountersSection <em>Encounters Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.EncountersSection
	* @generated
	*/
	public Adapter createEncountersSectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareSection <em>Plan Of Care Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareSection
	* @generated
	*/
	public Adapter createPlanOfCareSectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivity <em>Plan Of Care Activity</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivity
	* @generated
	*/
	public Adapter createPlanOfCareActivityAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivityAct <em>Plan Of Care Activity Act</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivityAct
	* @generated
	*/
	public Adapter createPlanOfCareActivityActAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivityEncounter <em>Plan Of Care Activity Encounter</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivityEncounter
	* @generated
	*/
	public Adapter createPlanOfCareActivityEncounterAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivityObservation <em>Plan Of Care Activity Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivityObservation
	* @generated
	*/
	public Adapter createPlanOfCareActivityObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivityProcedure <em>Plan Of Care Activity Procedure</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivityProcedure
	* @generated
	*/
	public Adapter createPlanOfCareActivityProcedureAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivitySubstanceAdministration <em>Plan Of Care Activity Substance Administration</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivitySubstanceAdministration
	* @generated
	*/
	public Adapter createPlanOfCareActivitySubstanceAdministrationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivitySupply <em>Plan Of Care Activity Supply</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.PlanOfCareActivitySupply
	* @generated
	*/
	public Adapter createPlanOfCareActivitySupplyAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ImmunizationsSection <em>Immunizations Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ImmunizationsSection
	* @generated
	*/
	public Adapter createImmunizationsSectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.VitalSignsSection <em>Vital Signs Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.VitalSignsSection
	* @generated
	*/
	public Adapter createVitalSignsSectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.VitalSignsOrganizer <em>Vital Signs Organizer</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.VitalSignsOrganizer
	* @generated
	*/
	public Adapter createVitalSignsOrganizerAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.MedicalEquipmentSection <em>Medical Equipment Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.MedicalEquipmentSection
	* @generated
	*/
	public Adapter createMedicalEquipmentSectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.FunctionalStatusSection <em>Functional Status Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.FunctionalStatusSection
	* @generated
	*/
	public Adapter createFunctionalStatusSectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.AdvanceDirectivesSection <em>Advance Directives Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.AdvanceDirectivesSection
	* @generated
	*/
	public Adapter createAdvanceDirectivesSectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.AdvanceDirectiveObservation <em>Advance Directive Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.AdvanceDirectiveObservation
	* @generated
	*/
	public Adapter createAdvanceDirectiveObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.PayersSection <em>Payers Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.PayersSection
	* @generated
	*/
	public Adapter createPayersSectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.CoverageActivity <em>Coverage Activity</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.CoverageActivity
	* @generated
	*/
	public Adapter createCoverageActivityAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.PolicyActivity <em>Policy Activity</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.PolicyActivity
	* @generated
	*/
	public Adapter createPolicyActivityAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.PurposeSection <em>Purpose Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.PurposeSection
	* @generated
	*/
	public Adapter createPurposeSectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.PurposeActivity <em>Purpose Activity</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.PurposeActivity
	* @generated
	*/
	public Adapter createPurposeActivityAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ProblemObservation <em>Problem Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ProblemObservation
	* @generated
	*/
	public Adapter createProblemObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ProblemStatusObservation <em>Problem Status Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ProblemStatusObservation
	* @generated
	*/
	public Adapter createProblemStatusObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.StatusObservation <em>Status Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.StatusObservation
	* @generated
	*/
	public Adapter createStatusObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ProblemHealthStatusObservation <em>Problem Health Status Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ProblemHealthStatusObservation
	* @generated
	*/
	public Adapter createProblemHealthStatusObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.AgeObservation <em>Age Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.AgeObservation
	* @generated
	*/
	public Adapter createAgeObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.PatientAwareness <em>Patient Awareness</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.PatientAwareness
	* @generated
	*/
	public Adapter createPatientAwarenessAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.FamilyHistoryObservation <em>Family History Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.FamilyHistoryObservation
	* @generated
	*/
	public Adapter createFamilyHistoryObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.FamilyHistoryOrganizer <em>Family History Organizer</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.FamilyHistoryOrganizer
	* @generated
	*/
	public Adapter createFamilyHistoryOrganizerAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.SocialHistoryObservation <em>Social History Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.SocialHistoryObservation
	* @generated
	*/
	public Adapter createSocialHistoryObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.SocialHistoryStatusObservation <em>Social History Status Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.SocialHistoryStatusObservation
	* @generated
	*/
	public Adapter createSocialHistoryStatusObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.EncountersActivity <em>Encounters Activity</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.EncountersActivity
	* @generated
	*/
	public Adapter createEncountersActivityAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.MedicationActivity <em>Medication Activity</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.MedicationActivity
	* @generated
	*/
	public Adapter createMedicationActivityAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.MedicationSeriesNumberObservation <em>Medication Series Number Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.MedicationSeriesNumberObservation
	* @generated
	*/
	public Adapter createMedicationSeriesNumberObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.MedicationStatusObservation <em>Medication Status Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.MedicationStatusObservation
	* @generated
	*/
	public Adapter createMedicationStatusObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.PatientInstruction <em>Patient Instruction</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.PatientInstruction
	* @generated
	*/
	public Adapter createPatientInstructionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.SupplyActivity <em>Supply Activity</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.SupplyActivity
	* @generated
	*/
	public Adapter createSupplyActivityAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.FulfillmentInstruction <em>Fulfillment Instruction</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.FulfillmentInstruction
	* @generated
	*/
	public Adapter createFulfillmentInstructionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.AlertObservation <em>Alert Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.AlertObservation
	* @generated
	*/
	public Adapter createAlertObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.AlertStatusObservation <em>Alert Status Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.AlertStatusObservation
	* @generated
	*/
	public Adapter createAlertStatusObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ReactionObservation <em>Reaction Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ReactionObservation
	* @generated
	*/
	public Adapter createReactionObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.SeverityObservation <em>Severity Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.SeverityObservation
	* @generated
	*/
	public Adapter createSeverityObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.CauseOfDeathObservation <em>Cause Of Death Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.CauseOfDeathObservation
	* @generated
	*/
	public Adapter createCauseOfDeathObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.EncounterLocation <em>Encounter Location</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.EncounterLocation
	* @generated
	*/
	public Adapter createEncounterLocationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.Product <em>Product</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.Product
	* @generated
	*/
	public Adapter createProductAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.AdvanceDirectiveStatusObservation <em>Advance Directive Status Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.AdvanceDirectiveStatusObservation
	* @generated
	*/
	public Adapter createAdvanceDirectiveStatusObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.AdvanceDirectiveVerification <em>Advance Directive Verification</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.AdvanceDirectiveVerification
	* @generated
	*/
	public Adapter createAdvanceDirectiveVerificationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.AuthorizationActivity <em>Authorization Activity</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.AuthorizationActivity
	* @generated
	*/
	public Adapter createAuthorizationActivityAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ProcedureActivity <em>Procedure Activity</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ProcedureActivity
	* @generated
	*/
	public Adapter createProcedureActivityAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.FunctionalStatusObservation <em>Functional Status Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.FunctionalStatusObservation
	* @generated
	*/
	public Adapter createFunctionalStatusObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ProductInstance <em>Product Instance</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ProductInstance
	* @generated
	*/
	public Adapter createProductInstanceAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ProcedureActivityAct <em>Procedure Activity Act</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ProcedureActivityAct
	* @generated
	*/
	public Adapter createProcedureActivityActAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ProcedureActivityObservation <em>Procedure Activity Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ProcedureActivityObservation
	* @generated
	*/
	public Adapter createProcedureActivityObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.ProcedureActivityProcedure <em>Procedure Activity Procedure</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.ProcedureActivityProcedure
	* @generated
	*/
	public Adapter createProcedureActivityProcedureAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.PayerEntity <em>Payer Entity</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.PayerEntity
	* @generated
	*/
	public Adapter createPayerEntityAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.CoveredParty <em>Covered Party</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.CoveredParty
	* @generated
	*/
	public Adapter createCoveredPartyAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.PolicySubscriber <em>Policy Subscriber</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.PolicySubscriber
	* @generated
	*/
	public Adapter createPolicySubscriberAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.CoveragePlanDescription <em>Coverage Plan Description</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.CoveragePlanDescription
	* @generated
	*/
	public Adapter createCoveragePlanDescriptionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.SupportParticipant <em>Support Participant</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.SupportParticipant
	* @generated
	*/
	public Adapter createSupportParticipantAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.Support <em>Support</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.Support
	* @generated
	*/
	public Adapter createSupportAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.SupportGuardian <em>Support Guardian</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.SupportGuardian
	* @generated
	*/
	public Adapter createSupportGuardianAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.Comment <em>Comment</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.Comment
	* @generated
	*/
	public Adapter createCommentAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.AdvanceDirectiveReference <em>Advance Directive Reference</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.AdvanceDirectiveReference
	* @generated
	*/
	public Adapter createAdvanceDirectiveReferenceAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.FamilyHistoryCauseOfDeathObservation <em>Family History Cause Of Death Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.FamilyHistoryCauseOfDeathObservation
	* @generated
	*/
	public Adapter createFamilyHistoryCauseOfDeathObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ccd.CCDRegistryDelegate <em>Registry Delegate</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ccd.CCDRegistryDelegate
	* @generated
	*/
	public Adapter createCCDRegistryDelegateAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.hl7.rim.InfrastructureRoot <em>Infrastructure Root</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.hl7.rim.InfrastructureRoot
	* @generated
	*/
	public Adapter createInfrastructureRootAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.hl7.rim.Act <em>Act</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.hl7.rim.Act
	* @generated
	*/
	public Adapter createActAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.Section <em>Section</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.Section
	* @generated
	*/
	public Adapter createSectionAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ClinicalDocument <em>Clinical Document</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ClinicalDocument
	* @generated
	*/
	public Adapter createClinicalDocumentAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ClinicalStatement <em>Clinical Statement</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ClinicalStatement
	* @generated
	*/
	public Adapter createClinicalStatementAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.Act <em>Act</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.Act
	* @generated
	*/
	public Adapter createCDA_ActAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.Observation <em>Observation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.Observation
	* @generated
	*/
	public Adapter createObservationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.Organizer <em>Organizer</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.Organizer
	* @generated
	*/
	public Adapter createOrganizerAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.Encounter <em>Encounter</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.Encounter
	* @generated
	*/
	public Adapter createEncounterAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.Procedure <em>Procedure</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.Procedure
	* @generated
	*/
	public Adapter createProcedureAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.SubstanceAdministration <em>Substance Administration</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.SubstanceAdministration
	* @generated
	*/
	public Adapter createSubstanceAdministrationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.Supply <em>Supply</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.Supply
	* @generated
	*/
	public Adapter createSupplyAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.hl7.rim.Participation <em>Participation</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.hl7.rim.Participation
	* @generated
	*/
	public Adapter createParticipationAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.Participant2 <em>Participant2</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.Participant2
	* @generated
	*/
	public Adapter createParticipant2Adapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.hl7.rim.Role <em>Role</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.hl7.rim.Role
	* @generated
	*/
	public Adapter createRoleAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ManufacturedProduct <em>Manufactured Product</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ManufacturedProduct
	* @generated
	*/
	public Adapter createManufacturedProductAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.ParticipantRole <em>Participant Role</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.ParticipantRole
	* @generated
	*/
	public Adapter createParticipantRoleAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.AssignedEntity <em>Assigned Entity</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.AssignedEntity
	* @generated
	*/
	public Adapter createAssignedEntityAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.Participant1 <em>Participant1</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.Participant1
	* @generated
	*/
	public Adapter createParticipant1Adapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.Guardian <em>Guardian</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.Guardian
	* @generated
	*/
	public Adapter createGuardianAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.hl7.rim.ActRelationship <em>Act Relationship</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.hl7.rim.ActRelationship
	* @generated
	*/
	public Adapter createActRelationshipAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.Reference <em>Reference</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.Reference
	* @generated
	*/
	public Adapter createReferenceAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for an object of class '{@link org.openhealthtools.mdht.uml.cda.RegistryDelegate <em>Registry Delegate</em>}'.
	* <!-- begin-user-doc -->
	 * This default implementation returns null so that we can easily ignore cases;
	 * it's useful to ignore a case when inheritance will catch all the cases anyway.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @see org.openhealthtools.mdht.uml.cda.RegistryDelegate
	* @generated
	*/
	public Adapter createRegistryDelegateAdapter() {
		return null;
	}

	/**
	* Creates a new adapter for the default case.
	* <!-- begin-user-doc -->
	 * This default implementation returns null.
	 * <!-- end-user-doc -->
	* @return the new adapter.
	* @generated
	*/
	public Adapter createEObjectAdapter() {
		return null;
	}

} // CCDAdapterFactory
